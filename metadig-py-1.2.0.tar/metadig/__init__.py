__version__ = '1.0'

from .checks import getType
from .checks import isResolvable
from .variable import isBlank
from .variable import toUnicode
